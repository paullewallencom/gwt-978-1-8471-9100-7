The files provided in this folder are to be used as explained in the chapter 7. The support files are given in the chapter download. You will need to use these files for proper running of code.
