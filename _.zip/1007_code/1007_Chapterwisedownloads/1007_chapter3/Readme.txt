The files provided in this folder are to be used as explained in the chapter 3.
