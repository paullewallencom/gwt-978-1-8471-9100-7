package com.packtpub.gwtbook.samples.client.util;

import com.google.gwt.i18n.client.Constants;

public interface I18NSamplesConstants extends Constants {
	String welcome();
	String flag_image();
}
